package CustomerManageByAdmin;

public class CusManageControler {
	
	
	
}
